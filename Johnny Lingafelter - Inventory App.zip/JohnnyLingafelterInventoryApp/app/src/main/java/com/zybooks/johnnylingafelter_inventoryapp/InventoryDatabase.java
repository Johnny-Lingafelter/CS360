/*
 *   InventoryDatabase.java
 *       - Controller for the database
 *
 *   Johnny Lingafelter - 6/15/2022
 *
 */
package com.zybooks.johnnylingafelter_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int VERSION = 1;

    private static InventoryDatabase mInvDb;

    /*************************************************************************
     * getInstance - returns the instance of the InventoryDatabase,
     *               InventoryDatabase uses a singleton design pattern
     * @param context - application context
     * @return - the one and only instance of the database
     *************************************************************************/
    public static InventoryDatabase getInstance(Context context) {
        if (mInvDb == null) {
            mInvDb = new InventoryDatabase(context);
        }
        return mInvDb;
    }

    /*******************************************************
     * Constructor - creates a new InventoryDatabase object
     * @param context - application context
     *******************************************************/
    public InventoryDatabase(Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    /**********************************************************************
     * UserTable - final var for table name and columns in the users table
     **********************************************************************/
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /*******************************************************************************
     * InventoryTable - final var for table name and columns in the inventory table
     *******************************************************************************/
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEMNAME = "item_name";
        private static final String COL_QUANTITY = "item_quantity";
    }

    /********************************************************************
     * onCreate - called when the database is created for the first time
     * @param db - the SQLiteDatabase object
     ********************************************************************/
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " password)");

        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEMNAME + " text, " +
                InventoryTable.COL_QUANTITY + " int)");
    }

    /********************************************************************
     * onUpgrade - called when the database is changed
     * @param db - the SQLiteDatabase object
     ********************************************************************/
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    /****************************************************
     * addUser - adds a user to the database
     * @param username - string containing the username
     * @param password - string containing the password
     *****************************************************/
    public void addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase(); // get the database

        // put values to insert in a ContentValues object
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);

        // insert the new user into the database
        db.insert(UserTable.TABLE, null, values);
        db.close(); // close the database
    }

    /*********************************************************************************************
     * getUser - queries the database for the given user
     * @param username - username to find
     * @return - User object containing user if found, otherwise an empty User object is returned
     *********************************************************************************************/
    public User getUser(String username) {
        SQLiteDatabase db = getReadableDatabase();

        // get all columns
        String columns[] = {UserTable.COL_ID, UserTable.COL_USERNAME, UserTable.COL_PASSWORD};
        String sel = UserTable.COL_USERNAME + " = ?";
        String args[] = {username};

        // query the database
        Cursor cursor = db.query(UserTable.TABLE, columns, sel, args, null, null, null);

        // moveToFirst will return false if there are no records retrieved
        if (cursor.moveToFirst()) {
            // get user data from cursor and return new User object
            int user_id = cursor.getInt(0);
            String user_name = cursor.getString(1);
            String user_pass = cursor.getString(2);
            return new User(user_id, user_name, user_pass);
        }
        // user was not found, return empty User object
        return new User();
    }

    /*******************************************************
     * addItem - adds an inventory item to the database
     * @param name - name of the item being added
     * @param quantity - quantity of the item being added
     ********************************************************/
    public void addItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        // put our values in a ContentValues object
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEMNAME, name);
        values.put(InventoryTable.COL_QUANTITY, quantity);

        // insert new item into database
        db.insert(InventoryTable.TABLE, null, values);
        db.close(); // close database
    }

    /***************************************************
     * getItems - gets all items from the database
     * @return - ArrayList of all items in the database
     ***************************************************/
    public ArrayList<Item> getItems() {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Item> items = new ArrayList<Item>();

        // raw sql query
        String sql = "select * from " + InventoryTable.TABLE;

        // run query
        Cursor cursor = db.rawQuery(sql, null);
        // check for results
        if (cursor.moveToFirst()) {
            do { // for each item...
                Item i = new Item(); // create empty item object
                // fill item with data from cursor record
                i.setId(Integer.parseInt(cursor.getString(0)));
                i.setName(cursor.getString(1));
                i.setQuantity(Integer.parseInt(cursor.getString(2)));
                // add item to the ArrayList
                items.add(i);
            } while (cursor.moveToNext()); // next item
        }
        db.close();     // close the database
        return items;   // return a list of all items
    }

    /**************************************************
     * deleteItem - deletes an item from the database
     * @param id - id of the item to be deleted
     **************************************************/
    public void deleteItem(String id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InventoryTable.TABLE, "_id = ?", new String[] {id});
        db.close();
    }

    /*****************************************************
     * updateItemQuantity - updates an item's quantity
     * @param id - the id of the item to update
     * @param quantity - the new quantity
     ******************************************************/
    public void updateItemQuantity(String id, int quantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, quantity);
        db.update(InventoryTable.TABLE, values, "_id = ?", new String[] {id});
        db.close();
    }
}
