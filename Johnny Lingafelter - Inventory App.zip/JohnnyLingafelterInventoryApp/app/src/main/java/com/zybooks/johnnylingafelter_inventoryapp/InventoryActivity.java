/*
 *   InventoryActivity.java
 *       - Controller for main screen inventory activity
 *
 *   Johnny Lingafelter - 6/15/2022
 *
 */
package com.zybooks.johnnylingafelter_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemClickListener, View.OnClickListener {

    // members for widgets used
    private FloatingActionButton mFABItem;
    private FloatingActionButton mFABMsg;
    private InventoryAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private InventoryDatabase mDB;
    private User mUser;

    // final for request code used in permissions
    private final int SMS_REQUEST_CODE = 99;

    /*****************************************************
     *  onCreate - initialize the view
     *****************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // store instance of database in member var
        mDB = InventoryDatabase.getInstance(getApplicationContext());

        // get recycler view widget and set its layout manager
        mRecyclerView = findViewById(R.id.inventoryRecycler);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this)); // ?

        // add a divider between rows
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mRecyclerView.getContext(), DividerItemDecoration.VERTICAL));

        // create new InventoryAdapter and store in member var, initialize with items from the DB
        mAdapter = new InventoryAdapter(getApplicationContext(), mDB.getItems());
        mAdapter.setClickListener(this);    // set adapter click listener
        mRecyclerView.setAdapter(mAdapter); // set recycler view's adapter

        // get FAB widgets
        mFABItem = findViewById(R.id.itemAdd);
        mFABMsg = findViewById(R.id.buttonMessage);

        // check permissions to see if we should show the permissions FAB
        String writePermission = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(this, writePermission) != PackageManager.PERMISSION_GRANTED) {
            // permission has not been granted yet, set on click listener for this FAB
            mFABMsg.setOnClickListener(this);
        }
        else {
            // permission has been granted, make the FAB invisible
            mFABMsg.setVisibility(View.GONE);
        }

        // set add item FAB click listener
        mFABItem.setOnClickListener(this);
    }

    /***************************************************************
     *  onResume - override this method to update the recycler view
     *              after an item has been added
     ***************************************************************/
    @Override
    public void onResume() {
        super.onResume();

        // refresh the adapter by making a new one getting all items from DB again
        // (there has to be a better way to do this, but I couldn't figure it out.
        // I would guess that I need to update the adapter's data and then call
        // notifyDataSetChanged() or something, but I don't know how to access
        // the adapter from the AddItemActivity class)
        mAdapter = new InventoryAdapter(getApplicationContext(), InventoryDatabase.getInstance(getApplicationContext()).getItems());
        mAdapter.setClickListener(this);    // set listener
        mRecyclerView.setAdapter(mAdapter); // set adapter
    }

    /*****************************************************************
     * onPlusClick  - called when user clicks the + button of an item
     * @param v - View that was clicked
     * @param position - position of clicked button in recycler view
     *****************************************************************/
    @Override
    public void onPlusClick(View v, int position) {

        // get all items from database and store in ArrayList
        InventoryDatabase db = InventoryDatabase.getInstance(getApplicationContext());
        ArrayList<Item> items = db.getItems();

        // get item based on position, and calculate new quantity
        Item item = items.get(position);
        int newQuantity = item.getQuantity() + 1;

        // update the item in the database using id of item and new quantity
        db.updateItemQuantity(String.valueOf(item.getId()), newQuantity);

        // find the text view containing quantity in this row
        ViewGroup row = (ViewGroup) v.getParent(); // have to get the parent cast as ViewGroup
        TextView tvCount = (TextView) row.findViewById(R.id.itemCount); // then find widget
        tvCount.setText(String.valueOf(newQuantity)); // set text to new quantity
    }

    /*****************************************************************
     * onMinusClick  - called when user clicks the - button of an item
     * @param v - View that was clicked
     * @param position - position of clicked button in recycler view
     *****************************************************************/
    @Override
    public void onMinusClick(View v, int position) {
        // get all items from database and store in ArrayList
        InventoryDatabase db = InventoryDatabase.getInstance(getApplicationContext());
        ArrayList<Item> items = db.getItems();

        // get item based on position, and calculate new quantity
        Item item = items.get(position);
        int quantity = item.getQuantity();

        // check for 0 quantity, if so we cannot decrease further
        if (quantity == 0) {
            Toast.makeText(getApplicationContext(), "Item out of stock! Cannot decrease quantity further.", Toast.LENGTH_SHORT).show();
        }
        else {
            // else, decrease quantity
            int newQuantity = item.getQuantity() - 1;

            // check if quantity is now 0, if so notify user and send SMS if permission allows
            if (newQuantity == 0) {
                String writePermission = Manifest.permission.SEND_SMS;
                if (ContextCompat.checkSelfPermission(this, writePermission) == PackageManager.PERMISSION_GRANTED) {
                    try {
                        // send SMS
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage("(555) 521-5554", null, item.getName() + " is out of stock!", null, null);
                        Toast.makeText(getApplicationContext(), "Item out of stock! SMS sent.", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    // do not send SMS but still notify user
                    Toast.makeText(getApplicationContext(), "Item out of stock!", Toast.LENGTH_SHORT).show();
                }
            }

            // update item in DB
            db.updateItemQuantity(String.valueOf(item.getId()), newQuantity);

            // update text view with new quantity
            ViewGroup row = (ViewGroup) v.getParent();
            TextView tvCount = (TextView) row.findViewById(R.id.itemCount);
            tvCount.setText(String.valueOf(newQuantity));
        }
    }

    /**********************************************************************
     * onDeleteClick  - called when user clicks the delete button of an item
     * @param v - View that was clicked
     * @param position - position of clicked button in recycler view
     **********************************************************************/
    @Override
    public void onDeleteClick(View v, int position) {
        // get all items from database
        InventoryDatabase db = InventoryDatabase.getInstance(getApplicationContext());
        ArrayList<Item> items = db.getItems();

        // get id of item being deleted
        String id = String.valueOf(items.get(position).getId());

        // delete item from db
        db.deleteItem(id);

        // update recycler view by notifying the adapter of the deletion
        mAdapter.removeItem(position);
        mAdapter.notifyItemRemoved(position);
    }

    /**********************************************************************
     * onClick  - listener to handle FABs in this view
     * @param v - View that was clicked
     **********************************************************************/
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.itemAdd: // add item FAB clicked, start AddItemActivity
                Intent intent = new Intent(getApplicationContext(), AddItemActivity.class);
                startActivity(intent);
                break;
            case R.id.buttonMessage: // request permission button clicked
                String writePermission = Manifest.permission.SEND_SMS;

                // check is permission is granted
                if (ContextCompat.checkSelfPermission(this, writePermission) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, writePermission)) {
                        // show dialog requesting permission
                        ActivityCompat.requestPermissions(this, new String[] {writePermission}, SMS_REQUEST_CODE);
                    }
                }
                break;
        }
    }

    /**********************************************************************
     * onRequestPermissionResult  - callback for permission dialog result
     **********************************************************************/
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // if this is our SMS request code
        if (requestCode == SMS_REQUEST_CODE) {
            // if permission was granted
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // notify user
                Toast.makeText(getApplicationContext(), "Permission to send SMS on out of stock items granted!", Toast.LENGTH_SHORT).show();
                // remove the FAB for message notification
                mFABMsg.setVisibility(View.GONE);
            }
            else {
                // permission denied, notify user
                Toast.makeText(getApplicationContext(), "Permission to send SMS on out of stock items denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}