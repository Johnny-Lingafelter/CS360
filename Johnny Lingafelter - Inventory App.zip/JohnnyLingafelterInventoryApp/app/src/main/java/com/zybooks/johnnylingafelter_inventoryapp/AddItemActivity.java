/*
*   AddItemActivity.java
*       - Controller for add item activity
*
*   Johnny Lingafelter - 6/15/2022
*
 */
package com.zybooks.johnnylingafelter_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity implements View.OnClickListener {

    // private member vars for relevant widgets
    private EditText etItemName;
    private EditText etItemQuantity;

    // private member for our database
    private InventoryDatabase DB;

    /*********************************************************
     *   onCreate - initialize the view and variables for use
     *********************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // get widgets
        etItemName = findViewById(R.id.editTextItemName);
        etItemQuantity = findViewById(R.id.editTextItemQuantity);

        // AddItemActivity implements OnClickListener
        // so set click listeners for buttons to 'this'
        findViewById(R.id.buttonItemAdd).setOnClickListener(this);
        findViewById(R.id.buttonItemCancel).setOnClickListener(this);

        // get our static instance of the database
        DB = InventoryDatabase.getInstance(getApplicationContext());
    }

    /******************************************************
    *   onClick - handle the Add Item button click event
    *******************************************************/
    @Override
    public void onClick(View v) {
        // if the Add Item button was clicked...
        if (v.getId() == R.id.buttonItemAdd) {
            // get the text in the edit text boxes
            String name = etItemName.getText().toString().trim();
            String quantityText = etItemQuantity.getText().toString().trim();

            // validate input, if nothing entered display toast to notify user
            if (name.length() == 0)
                Toast.makeText(getApplicationContext(), "Please enter item name.", Toast.LENGTH_SHORT).show();
            // check that quantity is also a positive number
            else if (quantityText.length() == 0 || !isPositiveNumber(quantityText))
                Toast.makeText(getApplicationContext(), "Please enter the item quantity", Toast.LENGTH_SHORT).show();
            else {
                // input is valid, cast quantity to int and add item to the database
                int quantity = Integer.parseInt(quantityText);
                DB.addItem(name, quantity);
                finish(); // finish activity
            }
        }
        // cancel button was clicked, do nothing and finish activity
        else {
            finish();
        }
    }

    /*********************************************************************************
    *   isPositiveNumber - private helper function for validating the input quantity
    **********************************************************************************/
    private boolean isPositiveNumber(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}