/*
 *   MainActivity.java
 *       - Controller for login screen activity
 *
 *   Johnny Lingafelter - 6/15/2022
 *
 */
package com.zybooks.johnnylingafelter_inventoryapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnCreate;
    private InventoryDatabase DB;

    /*************************************************
     *  onCreate - initialize the view
     *************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get widgets
        etUsername = (EditText)findViewById(R.id.editTextUsername);
        etPassword = (EditText)findViewById(R.id.editTextPassword);
        btnLogin = (Button)findViewById(R.id.buttonLogin);
        btnCreate = (Button)findViewById(R.id.buttonCreateAccount);

        // set click listeners
        btnLogin.setOnClickListener(this);
        btnCreate.setOnClickListener(this);

        // get database instance
        DB = InventoryDatabase.getInstance(getApplicationContext());
    }

    /********************************************************************
     * onClick - click listener for the login and create account buttons
     * @param v
     ********************************************************************/
    @Override
    public void onClick(View v) {
        // get text from username and password edit text widgets
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // validate input, text boxes should not be empty
        if (username.length() == 0)
            Toast.makeText(getApplicationContext(), "Please enter username!", Toast.LENGTH_SHORT).show();
        else if (password.length() == 0)
            Toast.makeText(getApplicationContext(), "Please enter password!", Toast.LENGTH_SHORT).show();
        else { // text boxes not empty, proceed

            // try to retrieve this user from the database
            User user = DB.getUser(username);

            // switch for which button was pressed
            switch (v.getId()) {
                case R.id.buttonLogin: // LOGIN button
                    // check entered username against user from DB
                    // (if our user object is not empty it should always match here)
                    if (!user.getUsername().equals(username))
                        Toast.makeText(getApplicationContext(), "User does not exist!", Toast.LENGTH_SHORT).show();
                    // check password
                    else if (!user.getPassword().equals(password))
                        Toast.makeText(getApplicationContext(), "Incorrect password!", Toast.LENGTH_SHORT).show();
                    else { // user exists, continue login
                        // start the main screen inventory activity
                        Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                        intent.putExtra("user_id", user.getId());
                        startActivity(intent);
                    }
                    break;

                case R.id.buttonCreateAccount: // CREATE ACCOUNT button
                    // check if user already exists
                    if (user.getUsername().equals(username))
                        Toast.makeText(getApplicationContext(), "User already exists! Please use Login button.", Toast.LENGTH_SHORT).show();
                    else {
                        // if user does not already exists, show dialog box
                        // confirming creation of new account
                        new AlertDialog.Builder(this)
                                .setTitle("Create Account")
                                .setMessage("Would you like to create an account using the entered username and password?")
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        // confirmation approved, add user to database
                                        DB.addUser(username, password);
                                        // start main inventory activity
                                        Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                                        startActivity(intent);
                                    }
                                })
                                .setNegativeButton(android.R.string.no, null).show();
                    }
                    break;
            }
        }
    }
}