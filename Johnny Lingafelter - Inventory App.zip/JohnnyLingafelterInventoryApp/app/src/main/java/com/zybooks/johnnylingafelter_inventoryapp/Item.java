/*
 *   Item.java
 *       - Model class for an inventory item
 *
 *   Johnny Lingafelter - 6/15/2022
 *
 */
package com.zybooks.johnnylingafelter_inventoryapp;

public class Item {
    private int mId;
    private String mName;
    private int mQuantity;

    public int getId() {
        return mId;
    }

    public String getName() {
        return mName;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setId(int id) {
        mId = id;
    }

    public void setName(String name) {
        mName = name;
    }

    public void setQuantity(int quantity) {
        mQuantity = quantity;
    }
}
