/*
 *   InventoryAdapter.java
 *       - Adapter for RecyclerView used to display inventory grid
 *
 *   Johnny Lingafelter - 6/15/2022
 *
 */
package com.zybooks.johnnylingafelter_inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemHolder> {

    // member variables for data, inflater, and click listener
    private ArrayList<Item> mItems;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;

    /****************************************************************
     * Constructor - creates a new adapter
     * @param context - application context
     * @param data - ArrayList of items used as data for the adapter
     ****************************************************************/
    public InventoryAdapter(Context context, ArrayList<Item> data) {
        mInflater = LayoutInflater.from(context);
        mItems = data;
    }

    /********************************************************************
     * onCreateViewHolder - called when the RecyclerView needs to create
     *                      a new view holder for items in the list
     * @param viewGroup - parent view group item is being added to
     * @param viewType - unused
     * @return - custom ItemHolder object
     *********************************************************************/
    @Override
    public ItemHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = mInflater.inflate(R.layout.inventory_row, viewGroup, false);
        ItemHolder ih = new ItemHolder(v);

        return ih;
    }

    /*****************************************************************
     * onBindViewHolder - called when the adapter needs to bind data
     *                      to a row's view in the RecyclerView
     * @param holder - the view holder
     * @param position - position of this row in the RecyclerView
     ******************************************************************/
    @Override
    public void onBindViewHolder(ItemHolder holder, final int position) {
        // set name and quantity of this item
        holder.getTvName().setText(mItems.get(position).getName());
        holder.getTvQuantity().setText(String.valueOf(mItems.get(position).getQuantity()));
    }

    /******************************************************************
     * getItemCount - override method for adapter to function properly
     * @return - size of the data array
     ******************************************************************/
    @Override
    public int getItemCount() {
        return mItems.size();
    }

    /************************************************************
     * removeItem - removes an item from the adapter's ArrayList
     * @param position - the index of this item in the list
     ************************************************************/
    public void removeItem(int position) {
        mItems.remove(position);
    }

    /*************************************************************************
     * setClickListener - needed because we need more than a single listener,
     *                      sets the ItemClickListener for the adapter
     * @param itemClickListener - the interface to be bound
     *************************************************************************/
    public void setClickListener(ItemClickListener itemClickListener) {
        mClickListener = itemClickListener;
    }

    /*********************************************************************************
     * ItemClickListener - abstract interface definition for click events on each row
     *  onPlusClick - listener for the increase quantity button (+)
     *  onMinusClick - listener for the decrease quantity button (-)
     *  onDeleteClick - listener for the delete item button
     *********************************************************************************/
    public interface ItemClickListener {
        void onPlusClick(View v, int position);
        void onMinusClick(View v, int position);
        void onDeleteClick(View v, int position);
    }

    /*******************************************************************************
     * ItemHolder - public class that defines the view holder for each
     *              row in the RecyclerView list, implements OnClickListener
     *******************************************************************************/
    public class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView tvName;
        private TextView tvQuantity;
        private Button btnPlus;
        private Button btnMinus;
        private Button btnDelete;

        /*****************************************************
         * Constructor - initializes a new ItemHolder object
         * @param v - parent container that holds the item
         *****************************************************/
        public ItemHolder(View v) {
            super(v);

            // get widgets for later use
            tvName = v.findViewById(R.id.itemName);
            tvQuantity = v.findViewById(R.id.itemCount);
            btnPlus = v.findViewById(R.id.buttonMinus);
            btnMinus = v.findViewById(R.id.buttonPlus);
            btnDelete = v.findViewById(R.id.buttonDeleteItem);

            // set all button click listeners to this class
            btnPlus.setOnClickListener(this);
            btnMinus.setOnClickListener(this);
            btnDelete.setOnClickListener(this);
        }

        /*********************************************
         * onClick - callback for buttons in this row
         * @param v - parent container
         *********************************************/
        @Override
        public void onClick(View v) {
            if (mClickListener != null) { // make sure the click listener exists
                switch (v.getId()) {
                    case R.id.buttonMinus:
                        mClickListener.onMinusClick(v, getAbsoluteAdapterPosition());
                        break;
                    case R.id.buttonPlus:
                        mClickListener.onPlusClick(v, getAbsoluteAdapterPosition());
                        break;
                    case R.id.buttonDeleteItem:
                        mClickListener.onDeleteClick(v, getAbsoluteAdapterPosition());
                        break;
                }
            }
        }

        /***********************************************
         * getTvName - getter for text view name widget
         * @return - the text view displaying item name
         ***********************************************/
        public TextView getTvName() {
            return tvName;
        }

        /*******************************************************
         * getTvQuantity - getter for text view quantity widget
         * @return - the text view displaying item quantity
         *******************************************************/
        public TextView getTvQuantity() {
            return tvQuantity;
        }
    }
}
